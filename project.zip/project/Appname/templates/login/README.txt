A Pen created at CodePen.io. You can find this one at http://codepen.io/DominicFrancois/pen/uoiHB.

 A pretty login form, that you can try to a certain extent of course. 